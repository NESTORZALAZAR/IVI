# OpenDyslexic Sources have moved. 
## Recent actions by Microsoft, including today's removal of Github's independence, and moving Github under CoreAI, make it an undesirable platform.

The annoucement that the current CEO will be leaving, and that Github will be moved under CoreAI is the latest in a long series of user-hostile actions.

Sources for OpenDyslexic were planned to move after Microsoft's actions in January, but things got in the way, I wanted a smoother transition, and needed a new home for it too. In the time since, I've found a new place to host OpenDyslexic and other projects (forgejo), and Microsoft has continued to take actions that harm people, including employee churn, doubling down on personal computer surveillance, and the removal of harassment protections from LinkedIn. 

OpenDyslexic (licensed as SIL-OFL) is now available on [https://forge.hackers.town/antijingoist/opendyslexic](https://forge.hackers.town/antijingoist/opendyslexic), and always available on [https://opendyslexic.org](https://opendyslexic.org),  along with links to updates and more. 

This version of OpenDyslexic is now available on [https://forge.hackers.town/antijingoist/open-dyslexic](https://forge.hackers.town/antijingoist/open-dyslexic)
